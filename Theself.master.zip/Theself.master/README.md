Bot Potect Group Line TCR-NEW UPDATE SCRIPT
Sediakan 4 akun Line Kalian untuk Bot nya dan 1 akun admin
Edit bagian mid admin dan owner,, ganti dengan mid kalian

Dibutuhkan Install :

- pip install rsa
- pip install request
- pip install thrift==0.9.3
