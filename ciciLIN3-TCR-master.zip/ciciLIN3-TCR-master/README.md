# LINE TCR
Forked from LINEALPHA [MerkKremont]

fixing some error and delete unusable code 

## Require to install
```
pip install rsa
pip install request
pip install thrift==0.9.3
```
